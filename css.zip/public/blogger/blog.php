<?php
      $title = "Blog";
      require_once('../include/functions/main.php');
      require('../include/layout/header.php');
 ?>

    <div class="container">

        <div class="row">

            <section class="blog-content col-sm-7 col-md-7">
                <div class="first-blog">
                  <h4 class="career-title text-center">How to be the best employee</h4>
                  <img class="blog-img img-responsive img-thumbnail center-block" src="img/smile.jpg" alt="" />
                      <p>
                          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. <br><a class="" href="#"><br>read more</a>
                      </p>
                </div>

                <hr>

                <div class="second-blog">
                  <h4 class="career-title">How to be the best employee</h4>
                      <img class="blog-img img-responsive center-block" src="img/smile.jpg" alt="" />
                      <p>
                          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. <br><a class="" href="#"><br>read more</a>
                      </p>
                </div>

                <hr>

                <div class="third-blog">
                  <h4 class="career-title">How to be the best employee</h4>
                  <img class="blog-img img-responsive center-block" src="img/smile.jpg" alt="" />
                      <p>
                          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. <br><a class="" href="#"><br>read more</a>
                      </p>
                </div>
            </section>

            <aside class="blog-aside col-sm-offset-1 col-md-offset-1 col-sm-4 col-md-4">
                <h3>Recent</h3>
                <h4 class="career-title">How to be the best employee</h4>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. <br><a class="" href="#"><br>read more</a>
                    </p>
            </aside>

        </div>

    </div>

 <?php
       require('../include/layout/page-header-footer.php');
       require('../include/layout/footer.php');
  ?>
