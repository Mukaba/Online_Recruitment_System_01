<?php
      $title = "Blog";
      require_once('include/functions/main.php');
      require('include/layout/header.php');
      require('include/layout/blog-header.php');
 ?>

    <div class="container-fluid blog-post">

        <div class="row">

            <section class="blog-content col-md-9">

            </section>

            <aside class="blog-aside col-md-3">

            </aside>

        </div>

    </div>

 <?php
       require('include/layout/page-header-footer.php');
       require('include/layout/footer.php');
  ?>
