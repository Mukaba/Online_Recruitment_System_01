<div class="rw"> <!--class="row"-->
  <div style="color:white;"class="page-header-footer">
      <h3 class="partner-header text-center">OUR HAPPY PARTNERS</h3>

      <div id="owl-demo" class="owl-carousel">
        <div class="item"><img class="img-responsive center-block partner-img"  src="img/exa.png" alt="Owl Image"></div>
        <div class="item"><img class="img-responsive center-block partner-img"  src="img/food.png" alt="Owl Image"></div>
        <div class="item"><img id="pg" class="img-responsive center-block partner-img"  src="img/pg.png" alt="Owl Image"></div>
        <div class="item"><img class="img-responsive center-block partner-img"  src="img/paper.png" alt="Owl Image"></div>
        <div class="item"><img class="img-responsive center-block partner-img" src="img/trans.png" alt="Owl Image"></div>
        <div class="item"><img class="img-responsive center-block partner-img"  src="img/synergy.png" alt="Owl Image"></div>
        <div class="item"><img id="andela" class="img-responsive center-block partner-img" src="img/andela.png" alt="Owl Image"></div>
        <div class="item"><img id="anakle" class="img-responsive center-block partner-img"  src="img/anakle.png" alt="Owl Image"></div>
        <div class="item"><img class="img-responsive center-block partner-img"  src="img/doormint.png" alt="Owl Image"></div>
        <div class="item"><img class="img-responsive center-block partner-img" src="img/volito.png" alt="Owl Image"></div>
        <div class="item"><img id="medina" class="img-responsive center-block partner-img"  src="img/medina.png" alt="Owl Image"></div>
        <div class="item"><img class="img-responsive center-block partner-img"  src="img/Diebold.png" alt="Owl Image"></div>
        <div class="item"><img class="img-responsive center-block partner-img" src="img/bouy.png" alt="Owl Image"></div>
        <div class="item"><img id="paypal" class="img-responsive center-block partner-img"  src="img/paypal.png" alt="Owl Image"></div>
        <div class="item"><img class="img-responsive center-block partner-img"  src="img/spectranet.png" alt="Owl Image"></div>
        <div class="item"><img class="img-responsive center-block partner-img"  src="img/exa.png" alt="Owl Image"></div>
      </div>

  </div>

</div>
