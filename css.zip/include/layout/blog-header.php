
<div class="container-fluid">
    <div style="margin-right:0px;margin-left:0px;" class="row">

      <div class="col-xs-12 col-sm-12 col-md-12 profile-top">

        <div class="dashboard-profile-display">

            <div class="blog-title col-md-12">
                <h1 class="text-center">BLOG</h1>
            </div>

        </div>



      </div>


    </div>
</div>
