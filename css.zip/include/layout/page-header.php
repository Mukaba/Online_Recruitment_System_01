<header><div class="header" style="background-color:black;" >

    <div class="overlay"></div>
</header>
    <div class="container search">

        <div class="row">

            <div class="col-xs-offset-0 col-sm-offset-2 col-md-offset-2 col-md-9 search-div">

              <form class="form-group searchform" action="index.html" method="post">

                  <div class="input-group">

                      <input class="form-control" type="search" name="name" value="" placeholder="Search with keywords. E.g: Accounting,  Human Resource, Engineering, Customer service" style="border-top-left-radius: 10px; border-bottom-left-radius: 10px;"><span class="input-group-addon" style="border-top-right-radius: 10px; border-bottom-right-radius: 10px;"><a href=""><i class="glyphicon glyphicon-search"></i></a></span>

                  </div>

              </form>

            </div>

        </div>

    </div>

</div>
