<?php
      require ('include/layout/jobseekersignin.php');
      require ('include/layout/employersignin.php');
      require ('include/layout/jobseekersignup.php');
?>
