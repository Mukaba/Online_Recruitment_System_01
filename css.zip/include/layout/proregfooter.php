      <footer>

          <div class="container">
              <div class="row">
                  <div class="row">
                    <div class="col-xs-4 col-md-3">
                      <ul>
                          <li><a href="#">Subscribe for newsletter</a></li>
                          <li><a href="#">Business guides</a></li>
                          <li><a href="#">About us</a></li>
                          <li><a href="#">Contact us</a></li>
                          <li><a href="#">About us</a></li>

                      </ul>
                    </div>
                    <div class="col-xs-4 col-md-3">
                      <ul>
                          <li><a href="#">Security</a></li>
                          <li><a href="#">Privacy</a></li>
                          <li><a href="#">About us</a></li>
                          <li><a href="#">Contact us</a></li>
                          <li><a href="#">About us</a></li>

                      </ul>
                    </div>
                    <div class="col-xs-4 col-md-3">
                      <ul>
                          <li><a href="#">Security</a></li>
                          <li><a href="#">Privacy</a></li>
                          <li><a href="#">About us</a></li>
                          <li><a href="#">Contact us</a></li>
                          <li><a href="#">About us</a></li>

                      </ul>
                    </div>
                    <div class="col-xs-12 col-sm-3">
                      <h5 class="follow-us">Follow us:</h5>
                      <ul class="icon-ul">
                          <li class="icon-li"><a href="#"><img src="icons/facebook32.png" class="img img-responsive" alt="" /></a></li>
                          <li class="icon-li"><a href="#"><img src="icons/instagram32.png" class="img img-responsive" alt="" /></a></li>
                          <li class="icon-li"><a href="#"><img src="icons/skype32.png" class="img img-responsive" alt="" /></a></li>
                          <li class="icon-li"><a href="#"><img src="icons/twitter32.png" class="img img-responsive" alt="" /></a></li>
                          <li class="icon-li"><a href="#"><img src="icons/linkedin32.png" class="img img-responsive" alt="" /></a></li>
                      </ul>
                    </div>
                  </div>

                  </div>
              </div>
              <hr id="divider">
              <div class="row">
                  <div class="col-md-12">
                      <h5 class="copyright text-center">&copy; Made by K. M. Jean-louis Raoul, ULK </h5>
                  </div>
              </div>
      </footer>

  </body>
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.datetimepicker.full.min.js"></script>
  <script src="js/jquery.validate.min.js"></script>
  <script src="js/additional-methods.min.js"></script>
  <script src="js/jquery-ui.min.js"></script>
  <script src="js/script.js"></script>
  <script src="js/jobseeker.js"></script>
</html>
