<?php
    // $dsn = 'mysql:host=localhost;dbname=jobportal';
    $dsn = 'mysql:host=localhost;dbname=smashjob';
    $pdo = new PDO($dsn, 'root', '');

    // require 'DatabasePlugin/database.php';
    // $database = new Database();
    // $host = "localhost";
    // $database_name = "smashjob";
    // $username = "root";
    // $password = "";
    // $pdo = $database->createConnection($host,$database_name,$username,$password);
 ?>
