https://github.com/profchydon/smashjob.git
## SMASHJOB

Smashjob is a simple web application built using PHP. It is an online job recruiting website that connects employers and job seekers.


## REQUIREMENTS

Server to process PHP codes - WAMP, LAMP etc.

## INSTALLATION

To install this project on your local machine, simply

1. Clone the repo

2. Make sure to import the smashjob.sql file to your database management system
